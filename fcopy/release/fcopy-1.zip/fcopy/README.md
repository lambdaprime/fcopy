**fcopy** - utility to copy files.

lambdaprime <id.blackmesa@gmail.com>


